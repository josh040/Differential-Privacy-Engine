from PyQt5 import QtCore, QtGui, QtWidgets
import csv

from PyQt5.QtWidgets import QMessageBox

from employee_records_window import Ui_MainWindow
from company_records_window import mainWindow
from employee_scatter_plot import Ui_Employee_Scatter_Plot
from company_scatter_plot import Ui_MainWindow_Company_Scatter_Plot

class Ui_MainWindow_employee_record(QtWidgets.QWidget):

    def __init__(s, fileName, parent=None):
        super(Ui_MainWindow_employee_record, s).__init__(parent)
        s.fileNameEmployee = "Read_Employee_Data.csv"
        s.fileNameAlteredEmployee = "Write_Employee_Data.csv"
        s.fileNameCompany = "Read_Company_Data.csv"
        s.fileNameAlteredCompany = "Write_Company_Data.csv"
        s.model = QtGui.QStandardItemModel(s)

        s.tableView = QtWidgets.QTableView(s)
        s.tableView.setModel(s.model)
        s.tableView.horizontalHeader().setStretchLastSection(True)
        s.tableView.setFixedSize(800, 600)

        s.load_employee_data_button = QtWidgets.QPushButton(s)
        s.load_employee_data_button.setText("Click here to view the original employee data")
        try:
            s.load_employee_data_button.clicked.connect(s.on_pushButtonLoad_clicked_employee)
        except EnvironmentError:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText("Error! Please close existing window.")
            msg.setInformativeText('You can only have one window open at a time. Please close the existing window to continue!')
            msg.setWindowTitle("Error")
            msg.exec_()
            pass
        s.load_altered_employee_data_button = QtWidgets.QPushButton(s)
        s.load_altered_employee_data_button.setText("Click here to view the altered employee data")
        s.load_altered_employee_data_button.setGeometry(QtCore.QRect(11, 645, 800, 25))
        s.load_altered_employee_data_button.clicked.connect(s.on_pushButtonLoad_clicked_altered_employee)

        s.load_company_data_button = QtWidgets.QPushButton(s)
        s.load_company_data_button.setText("Click here to view the original company data")
        s.load_company_data_button.setGeometry(QtCore.QRect(11, 675, 800, 25))
        s.load_company_data_button.clicked.connect(s.on_pushButtonLoad_clicked_company)

        s.load_altered_company_data_button = QtWidgets.QPushButton(s)
        s.load_altered_company_data_button.setText("Click here to view the altered company data")
        s.load_altered_company_data_button.setGeometry(QtCore.QRect(11, 705, 800, 25))
        s.load_altered_company_data_button.clicked.connect(s.on_pushButtonLoad_clicked_altered_company)

        s.layoutVertical = QtWidgets.QVBoxLayout(s)
        s.layoutVertical.addWidget(s.tableView)
        s.layoutVertical.addWidget(s.load_employee_data_button)
        s.layoutVertical.addSpacing(220)
        s.welcomeLabel = QtWidgets.QLabel(s)
        s.welcomeLabel.setGeometry(QtCore.QRect(230, 735, 500, 25))
        s.navigationLabel = QtWidgets.QLabel(s)
        s.navigationLabel.setGeometry(QtCore.QRect(155, 760, 700, 25))
        font = QtGui.QFont()
        font.setFamily("MS PGothic")
        font.setPointSize(16)
        s.welcomeLabel.setFont(font)
        s.welcomeLabel.setText("Welcome to the Differential Privacy Engine!")
        s.navigationLabel.setFont(font)
        s.navigationLabel.setText("To begin, please select a dataset you would like to work with.")

        s.employee_record_button = QtWidgets.QPushButton(s)
        s.employee_record_button.setText("Apply DP to Employee Records")
        s.employee_record_button.setGeometry(QtCore.QRect(11, 800, 450, 25))
        s.employee_record_button.clicked.connect(s.employee_one_openWindow)

        s.employee_scatter_plot_button = QtWidgets.QPushButton(s)
        s.employee_scatter_plot_button.setText("View a scatter plot comparision for Employee Records")
        s.employee_scatter_plot_button.setGeometry(QtCore.QRect(11, 830, 450, 25))
        s.employee_scatter_plot_button.clicked.connect(s.employee_one_scatter_plot_openWindow)

        s.company_record_button = QtWidgets.QPushButton(s)
        s.company_record_button.setText("Apply DP to Company Records")
        s.company_record_button.setGeometry(QtCore.QRect(420, 800, 380, 25))
        s.company_record_button.clicked.connect(s.company_one_openWindow)

        s.company_scatter_plot_button = QtWidgets.QPushButton(s)
        s.company_scatter_plot_button.setText("View a scatter plot comparision for Company Records")
        s.company_scatter_plot_button.setGeometry(QtCore.QRect(420, 830, 380, 25))
        s.company_scatter_plot_button.clicked.connect(s.company_one_scatter_plot_openWindow)



    def loadCsv(s, fileName):
        s.model.clear()
        with open(fileName, "r") as fileInput:
            for row in csv.reader(fileInput):
                items = [
                    QtGui.QStandardItem(field)
                    for field in row
                ]
                s.model.appendRow(items)

    @QtCore.pyqtSlot()
    def on_pushButtonLoad_clicked_employee(s):
        s.loadCsv(s.fileNameEmployee)

    @QtCore.pyqtSlot()
    def on_pushButtonLoad_clicked_altered_employee(s):
        s.loadCsv(s.fileNameAlteredEmployee)

    @QtCore.pyqtSlot()
    def on_pushButtonLoad_clicked_company(s):
        s.loadCsv(s.fileNameCompany)

    @QtCore.pyqtSlot()
    def on_pushButtonLoad_clicked_altered_company(s):
        s.loadCsv(s.fileNameAlteredCompany)

    def employee_one_openWindow(s):
        s.window = QtWidgets.QMainWindow()
        s.ui = Ui_MainWindow()
        s.ui.setupUi(s.window)
        s.window.show()

    def altered_employee_one_openWindow(s):
        s.window = QtWidgets.QMainWindow()
        s.ui = Ui_MainWindow()
        s.ui.setupUi(s.window)
        s.window.show()

    def employee_one_scatter_plot_openWindow(s):
        s.window = QtWidgets.QMainWindow()
        s.ui = Ui_Employee_Scatter_Plot()
        s.ui.setupUi(s.window)
        s.window.show()

    def company_one_openWindow(s):
        s.window = QtWidgets.QMainWindow()
        s.ui = mainWindow()
        s.ui.setupUi(s.window)
        s.window.show()

    def altered_company_one_openWindow(s):
        s.window = QtWidgets.QMainWindow()
        s.ui = mainWindow()
        s.ui.setupUi(s.window)
        s.window.show()


    def company_one_scatter_plot_openWindow(s):
        s.window = QtWidgets.QMainWindow()
        s.ui =  Ui_MainWindow_Company_Scatter_Plot()
        s.ui.setupUi(s.window)
        s.window.show()


if __name__ == "__main__":
    import sys

    application = QtWidgets.QApplication(sys.argv)
    application.setApplicationName('Differential Privacy Engine')

    m = Ui_MainWindow_employee_record("data.csv")
    m.show()

    altered_employee_data = "Write_Employee_Data.csv"
    a = open(altered_employee_data, "w+")
    a.close()

    altered_company_data = "Write_Company_Data.csv"
    a = open(altered_company_data, "w+")
    a.close()

    sys.exit(application.exec_())
