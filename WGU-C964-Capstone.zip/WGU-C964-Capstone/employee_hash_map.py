class HashTableEntry:

    def __init__(s, k, i):
        s.k = k
        s.i = i


class Employee_HashMap:


    def __init__(s, initial_capacity=10):

        s.map = []
        for i in range(initial_capacity):
            s.map.append([])


    def _get_hash(s, k):
        bucket = int(k) % len(s.map)
        return bucket


    def insert(s, k, value):
        key_hash = s._get_hash(k)
        key_value = [k, value]

        if s.map[key_hash] is None:
            s.map[key_hash] = list([key_value])
            return True
        else:
            for pair in s.map[key_hash]:
                if pair[0] == k:
                    pair[1] = key_value
                    return True
            s.map[key_hash].append(key_value)
            return True

    def update(s, k, value):
        key_hash = s._get_hash(k)
        if s.map[key_hash] is not None:
            for pair in s.map[key_hash]:
                if pair[0] == k:
                    pair[1] = value
                    print(pair[1])
                    return True
        else:
            print('There was an error with updating on k: ' + k)


    def get(s, k):
        key_hash = s._get_hash(k)
        if s.map[key_hash] is not None:
            for pair in s.map[key_hash]:
                if pair[0] == k:
                    return pair[1]
        return None


    def delete(s, k):
        key_hash = s._get_hash(k)

        if s.map[key_hash] is None:
            return False
        for i in range(0, len(s.map[key_hash])):
            if s.map[key_hash][i][0] == k:
                s.map[key_hash].pop(i)
                return True
        return False