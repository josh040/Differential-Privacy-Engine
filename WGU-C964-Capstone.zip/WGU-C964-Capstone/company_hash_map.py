class HashTableEntry:

    def __init__(s, k, i):
        s.k = k
        s.i = i


class companyHashMap:


    def __init__(s, initCap=10):

        s.m = []
        for i in range(initCap):
            s.m.append([])


    def getHash(s, k):
        b = int(k) % len(s.m)
        return b


    def i(s, k, v):
        hash = s.getHash(k)
        value = [k, v]

        if s.m[hash] is None:
            s.m[hash] = list([value])
            return True
        else:
            for p in s.m[hash]:
                if p[0] == k:
                    p[1] = value
                    return True
            s.m[hash].append(value)
            return True

    def u(s, k, v):
        hash = s.getHash(k)
        if s.m[hash] is not None:
            for p in s.m[hash]:
                if p[0] == k:
                    p[1] = v
                    print(p[1])
                    return True
        else:
            print('Problem updating on this k: ' + k)


    def g(s, k):
        hash = s.getHash(k)
        if s.m[hash] is not None:
            for p in s.m[hash]:
                if p[0] == k:
                    return p[1]
        return None


    def d(s, k):
        hash = s.getHash(k)

        if s.m[hash] is None:
            return False
        for i in range(0, len(s.m[hash])):
            if s.m[hash][i][0] == k:
                s.m[hash].pop(i)
                return True
        return False
