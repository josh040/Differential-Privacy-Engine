from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import  QMessageBox
from employee_hash_map import Employee_HashMap
import numpy as np
import csv
import random

noiseCounter1 = 0
noiseCounter2 = 0
insert_into_hash_table = Employee_HashMap()

def employee_name_values():
    employee_array = np.arange(1, 101)
    employee_name_array = [None]
    for I in range(len(employee_array)):
        try:
            r = random.randint(1, 1000)
            employee_name_array[I] = get_hash_map().get(str(r))[1]
        except IndexError:
            pass
    format_list = str(employee_name_array)[2:-2]
    return format_list


def employee_email_vales():
    employee_array = np.arange(1, 101)
    employee_name_array = [None]
    for i in range(len(employee_array)):
        try:
            r = random.randint(1, 1000)
            employee_name_array[i] = get_hash_map().get(str(r))[3]
        except IndexError:
            pass
    format_list = str(employee_name_array)[2:-2]
    return format_list


def update_noise_counter_one():
    global noiseCounter1
    n = noiseCounter1 + 1
    noiseCounter2 = n
    return n


def update_noise_counter_two():
    global noiseCounter2
    n = noiseCounter2 + 1
    noiseCounter2 = n
    return n


def get_hash_map():
    return insert_into_hash_table


def read_employee_records():
    with open('Read_Employee_Data.csv') as csvfile:
        read_CSV = csv.reader(csvfile, delimiter=',')

        for row in read_CSV:
            employee_id = row[0]
            employee_first_name = row[1]
            employee_last_name = row[2]
            employee_email = row[3]
            employee_gender = row[4]
            employee_job_title = row[5]
            employee_record = [employee_id, employee_first_name, employee_last_name, employee_email, employee_gender, employee_job_title]

            k = employee_id
            value = employee_record

            insert_into_hash_table.insert(k, value)

def write_employee_records():
    with open('Write_Employee_Data.csv', mode='w', newline='') as csvfile:
        writeCSV = csv.writer(csvfile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        test_array = np.arange(1, 1002)
        try:
            for i in range(len(test_array)):
                if i == 0:
                    pass
                else:
                    writeCSV.writerow(get_hash_map().get(str(i)))
        except IndexError:
            pass


def employee_data_filter_one_names(data, i, updated):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            data = employee_name_values()
            get_hash_map().get(str(i))[updated] = data
            update_noise_counter_one()


def employee_data_filter_one_emails(data, i, updated):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            data = employee_email_vales()
            get_hash_map().get(str(i))[updated] = data
            update_noise_counter_one()


def employee_data_filter_two_names(data, i, updated):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            r = random.randint(0, 1)
            if r == 0:
                pass
            else:
                data = employee_name_values()
                get_hash_map().get(str(i))[updated] = data
                update_noise_counter_two()


def employee_data_filter_two_emails(data, i, updated):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            r = random.randint(0, 1)
            if r == 0:
                pass
            else:
                data = employee_email_vales()
                get_hash_map().get(str(i))[updated] = data
                update_noise_counter_two()



class Ui_MainWindow(object):

    test_array = np.arange(1, 1001)

    def setupUi(s, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(593, 393)
        s.centralwidget = QtWidgets.QWidget(MainWindow)
        s.centralwidget.setObjectName("centralwidget")
        s.first_filter_label = QtWidgets.QLabel(s.centralwidget)
        s.first_filter_label.setGeometry(QtCore.QRect(10, 30, 391, 61))
        font = QtGui.QFont()
        font.setPointSize(12)
        s.first_filter_label.setFont(font)
        s.first_filter_label.setObjectName("first_filter_label")
        s.first_privacy_field_combo_box = QtWidgets.QComboBox(s.centralwidget)
        s.first_privacy_field_combo_box.setGeometry(QtCore.QRect(440, 40, 141, 31))
        s.first_privacy_field_combo_box.setObjectName("first_privacy_field_combo_box")
        s.first_privacy_field_combo_box.addItem("")
        s.first_privacy_field_combo_box.addItem("")
        s.first_privacy_field_combo_box.addItem("")
        s.label_2 = QtWidgets.QLabel(s.centralwidget)
        s.label_2.setGeometry(QtCore.QRect(210, 10, 161, 21))
        font = QtGui.QFont()
        font.setPointSize(14)
        s.label_2.setFont(font)
        s.label_2.setObjectName("label_2")
        s.second_filter_label = QtWidgets.QLabel(s.centralwidget)
        s.second_filter_label.setGeometry(QtCore.QRect(10, 100, 421, 61))
        font = QtGui.QFont()
        font.setPointSize(12)
        s.second_filter_label.setFont(font)
        s.second_filter_label.setObjectName("second_filter_label")
        s.second_privacy_field_combo_box = QtWidgets.QComboBox(s.centralwidget)
        s.second_privacy_field_combo_box.setGeometry(QtCore.QRect(440, 110, 141, 31))
        s.second_privacy_field_combo_box.setObjectName("second_privacy_field_combo_box")
        s.second_privacy_field_combo_box.addItem("")
        s.second_privacy_field_combo_box.addItem("")
        s.second_privacy_field_combo_box.addItem("")
        s.DP_button = QtWidgets.QPushButton(s.centralwidget)
        s.DP_button.setGeometry(QtCore.QRect(10, 160, 571, 31))
        s.DP_button.setObjectName("DP_button")

        s.DP_button.clicked.connect(s.pressed)

        s.first_data_set_label = QtWidgets.QLabel(s.centralwidget)
        s.first_data_set_label.setGeometry(QtCore.QRect(10, 200, 561, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        s.first_data_set_label.setFont(font)
        s.first_data_set_label.setObjectName("first_data_set_label")
        s.second_data_set_label = QtWidgets.QLabel(s.centralwidget)
        s.second_data_set_label.setGeometry(QtCore.QRect(10, 240, 561, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        s.second_data_set_label.setFont(font)
        s.second_data_set_label.setObjectName("second_data_set_label")
        s.third_data_set_label = QtWidgets.QLabel(s.centralwidget)
        s.third_data_set_label.setGeometry(QtCore.QRect(10, 280, 561, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        s.third_data_set_label.setFont(font)
        s.third_data_set_label.setObjectName("third_data_set_label")
        s.main_menu_text = QtWidgets.QLabel(s.centralwidget)
        s.main_menu_text.setGeometry(QtCore.QRect(10, 320, 581, 16))
        font = QtGui.QFont()
        font.setPointSize(9)
        s.main_menu_text.setFont(font)
        s.main_menu_text.setObjectName("main_menu_text")

        MainWindow.setCentralWidget(s.centralwidget)
        s.statusbar = QtWidgets.QStatusBar(MainWindow)
        s.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(s.statusbar)

        s.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(s, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Differential Privacy Engine"))
        s.first_filter_label.setText(_translate("MainWindow", "Please enter the first field to apply privacy filtering on:"))
        s.first_privacy_field_combo_box.setItemText(0, _translate("MainWindow", "First Name"))
        s.first_privacy_field_combo_box.setItemText(1, _translate("MainWindow", "Last Name"))
        s.first_privacy_field_combo_box.setItemText(2, _translate("MainWindow", "Email"))
        s.label_2.setText(_translate("MainWindow", "Employee Records "))
        s.second_filter_label.setText(_translate("MainWindow", "Please enter the second field to apply privacy filtering on:"))
        s.second_privacy_field_combo_box.setItemText(0, _translate("MainWindow", "First Name"))
        s.second_privacy_field_combo_box.setItemText(1, _translate("MainWindow", "Last Name"))
        s.second_privacy_field_combo_box.setItemText(2, _translate("MainWindow", "Email"))
        s.DP_button.setText(_translate("MainWindow", "Apply Differential Privacy Filtering"))
        s.first_data_set_label.setText(_translate("MainWindow", "Change applied to first data set: 0.00%"))
        s.second_data_set_label.setText(_translate("MainWindow", "Change applied to second data set: 0.00%"))
        s.third_data_set_label.setText(_translate("MainWindow", "Total change applied to data set: 0.00%"))
        s.main_menu_text.setText(_translate("MainWindow", "To view the altered employee records dataset, go back to the main menu"))

    def pressed(s):
        first_employee_filter = str(s.first_privacy_field_combo_box.currentText())
        second_employee_filter = str(s.second_privacy_field_combo_box.currentText())

        read_employee_records()
        test = np.arange(1, 1001)
        try:
            if first_employee_filter == "First Name":
                field_to_be_updated_one = 1
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        employee_data_filter_one_names(get_hash_map().get(str(test[index]))[1], test[index],
                                                   field_to_be_updated_one)
                s.first_data_set_label.setText("Change applied to first data set: " + "{:.2%}".format(
                    int(update_noise_counter_one()) / len(test)))
            if first_employee_filter == "Last Name":
                field_to_be_updated_one = 2
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        employee_data_filter_one_names(get_hash_map().get(str(test[index]))[1], test[index],
                                                   field_to_be_updated_one)
                s.first_data_set_label.setText("Change applied to first data set: " + "{:.2%}".format(
                    int(update_noise_counter_one()) / len(test)))
            if first_employee_filter == "Email":
                field_to_be_updated_one = 3
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        employee_data_filter_one_emails(get_hash_map().get(str(test[index]))[1], test[index],
                                                   field_to_be_updated_one)
                s.first_data_set_label.setText("Change applied to first data set: " + "{:.2%}".format(
                    int(update_noise_counter_one()) / len(test)))
            if second_employee_filter == "First Name":
                field_to_be_updated_two = 1
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        employee_data_filter_two_names(get_hash_map().get(str(test[index]))[3], test[index],
                                                   field_to_be_updated_two)
                s.second_data_set_label.setText("Change applied to second data set: " + "{:.2%}".format(
                    int(update_noise_counter_two()) / len(test)))
            if second_employee_filter == "Last Name":
                field_to_be_updated_two = 2
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        employee_data_filter_two_names(get_hash_map().get(str(test[index]))[3], test[index],
                                                   field_to_be_updated_two)
                s.second_data_set_label.setText("Change applied to second data set: " + "{:.2%}".format(
                    int(update_noise_counter_two()) / len(test)))
            if second_employee_filter == "Email":
                field_to_be_updated_two = 3
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        employee_data_filter_two_emails(get_hash_map().get(str(test[index]))[3], test[index],
                                                   field_to_be_updated_two)
                s.second_data_set_label.setText("Change applied to second data set: " + "{:.2%}".format(
                    int(update_noise_counter_two()) / len(test)))

            s.third_data_set_label.setText("Total change applied to data set: " + "{: .2%}".format(int(noiseCounter1 + noiseCounter2) / 6000))

            altered_data = "Write_Employee_Data.csv"
            a = open(altered_data, "w+")
            a.close()
            write_employee_records()

        except IndexError:
            message = QMessageBox()
            message.setIcon(QMessageBox.Critical)
            message.setText("Error with data update.")
            message.setInformativeText('You can only apply the noise to this data set once, please restart the application!')
            message.setWindowTitle("Error")
            message.exec_()
            pass


if __name__ == "__main__":
    import sys
    application = QtWidgets.QApplication(sys.argv)
    main = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(main)
    main.show()
    sys.exit(application.exec_())
