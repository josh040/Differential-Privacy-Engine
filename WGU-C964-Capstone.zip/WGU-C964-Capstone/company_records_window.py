from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import  QMessageBox
from company_hash_map import companyHashMap
import numpy as np
import csv
import random

noiseCounter1 = 0
noiseCounter2 = 0
insertIntoHashTable = companyHashMap()

def companyNameValues():
    array = np.arange(1, 101)
    nameArray = [None]
    for i in range(len(array)):
        try:
            r = random.randint(1, 1000)
            nameArray[i] = getHashMap().g(str(r))[1]
        except IndexError:
            pass
    formatList = str(nameArray)[2:-2]
    return formatList


def countryValues():
    Array = np.arange(1, 101)
    countryArray = [None]
    for i in range(len(Array)):
        try:
            r = random.randint(1, 1000)
            countryArray[i] = getHashMap().g(str(r))[3]
        except IndexError:
            pass
    format_list = str(countryArray)[2:-2]
    return format_list


def update1():
    global noiseCounter1
    noise = noiseCounter1 + 1
    noiseCounter1 = noise
    return noise


def update2():
    global noiseCounter2
    noise = noiseCounter2 + 1
    noiseCounter2 = noise
    return noise


def getHashMap():
    return insertIntoHashTable


def read_company_records():
    with open('Read_Company_Data.csv') as csvfile:
        read_CSV = csv.reader(csvfile, delimiter=',')

        for row in read_CSV:
            company_id = row[0]
            company_name = row[1]
            company_country = row[2]
            company_value = row[3]
            company_website = row[4]

            company_record = [company_id, company_name, company_country, company_value, company_website]

            k = company_id
            value = company_record

            insertIntoHashTable.i(k, value)


def write_company_records():
    with open('Write_Company_Data.csv', mode='w', newline='') as csvfile:
        writeCSV = csv.writer(csvfile, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        test_array = np.arange(1, 1002)
        try:
            for i in range(len(test_array)):
                if i == 0:
                    pass
                else:
                    writeCSV.writerow(getHashMap().g(str(i)))
        except IndexError:
            pass


def filterNames1(data, i, update):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            data = companyNameValues()
            getHashMap().g(str(i))[update] = data
            update1()


def filter1COuntries(data, i, update):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            data = countryValues()
            getHashMap().g(str(i))[update] = data
            update1()


def values1(data, i, update):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            data = countryValues()
            getHashMap().g(str(i))[update] = data
            update1()


def names2(data, i, updated):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            r = random.randint(0, 1)
            if r == 0:
                pass
            else:
                data = companyNameValues()
                getHashMap().g(str(i))[updated] = data
                update2()


def countries2(data, i, updated):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            r = random.randint(0, 1)
            if r == 0:
                pass
            else:
                data = countryValues()
                getHashMap().g(str(i))[updated] = data
                update2()


def values2(data, i, updated):
    r = random.randint(0, 1)
    if r == 0:
        pass
    else:
        r = random.randint(0, 1)
        if r == 0:
            pass
        else:
            data = countryValues()
            getHashMap().g(str(i))[updated] = data
            update2()


class mainWindow(object):

    test_array = np.arange(1, 1001)

    def setupUi(s, main):
        main.setObjectName("MainWindow")
        main.resize(593, 393)
        s.centralwidget = QtWidgets.QWidget(main)
        s.centralwidget.setObjectName("centralwidget")
        s.first_filter_label = QtWidgets.QLabel(s.centralwidget)
        s.first_filter_label.setGeometry(QtCore.QRect(10, 30, 391, 61))
        font = QtGui.QFont()
        font.setPointSize(12)
        s.first_filter_label.setFont(font)
        s.first_filter_label.setObjectName("first_filter_label")
        s.first_privacy_field_combo_box = QtWidgets.QComboBox(s.centralwidget)
        s.first_privacy_field_combo_box.setGeometry(QtCore.QRect(440, 40, 141, 31))
        s.first_privacy_field_combo_box.setObjectName("first_privacy_field_combo_box")
        s.first_privacy_field_combo_box.addItem("")
        s.first_privacy_field_combo_box.addItem("")
        s.first_privacy_field_combo_box.addItem("")
        s.label_2 = QtWidgets.QLabel(s.centralwidget)
        s.label_2.setGeometry(QtCore.QRect(210, 10, 161, 21))
        font = QtGui.QFont()
        font.setPointSize(14)
        s.label_2.setFont(font)
        s.label_2.setObjectName("label_2")
        s.second_filter_label = QtWidgets.QLabel(s.centralwidget)
        s.second_filter_label.setGeometry(QtCore.QRect(10, 100, 421, 61))
        font = QtGui.QFont()
        font.setPointSize(12)
        s.second_filter_label.setFont(font)
        s.second_filter_label.setObjectName("second_filter_label")
        s.second_privacy_field_combo_box = QtWidgets.QComboBox(s.centralwidget)
        s.second_privacy_field_combo_box.setGeometry(QtCore.QRect(440, 110, 141, 31))
        s.second_privacy_field_combo_box.setObjectName("second_privacy_field_combo_box")
        s.second_privacy_field_combo_box.addItem("")
        s.second_privacy_field_combo_box.addItem("")
        s.second_privacy_field_combo_box.addItem("")
        s.DP_button = QtWidgets.QPushButton(s.centralwidget)
        s.DP_button.setGeometry(QtCore.QRect(10, 160, 571, 31))
        s.DP_button.setObjectName("DP_button")

        s.DP_button.clicked.connect(s.press)

        s.first_data_set_label = QtWidgets.QLabel(s.centralwidget)
        s.first_data_set_label.setGeometry(QtCore.QRect(10, 200, 561, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        s.first_data_set_label.setFont(font)
        s.first_data_set_label.setObjectName("first_data_set_label")
        s.second_data_set_label = QtWidgets.QLabel(s.centralwidget)
        s.second_data_set_label.setGeometry(QtCore.QRect(10, 240, 561, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        s.second_data_set_label.setFont(font)
        s.second_data_set_label.setObjectName("second_data_set_label")
        s.third_data_set_label = QtWidgets.QLabel(s.centralwidget)
        s.third_data_set_label.setGeometry(QtCore.QRect(10, 280, 561, 41))
        font = QtGui.QFont()
        font.setPointSize(14)
        s.third_data_set_label.setFont(font)
        s.third_data_set_label.setObjectName("third_data_set_label")
        s.main_menu_text = QtWidgets.QLabel(s.centralwidget)
        s.main_menu_text.setGeometry(QtCore.QRect(10, 320, 581, 16))
        font = QtGui.QFont()
        font.setPointSize(9)
        s.main_menu_text.setFont(font)
        s.main_menu_text.setObjectName("main_menu_text")

        main.setCentralWidget(s.centralwidget)
        s.statusbar = QtWidgets.QStatusBar(main)
        s.statusbar.setObjectName("statusbar")
        main.setStatusBar(s.statusbar)

        s.retranslate(main)
        QtCore.QMetaObject.connectSlotsByName(main)

    def retranslate(s, main):
        _translate = QtCore.QCoreApplication.translate
        main.setWindowTitle(_translate("MainWindow", "Differential Privacy Engine"))
        s.first_filter_label.setText(_translate("MainWindow", "Please enter the first field to apply privacy filtering on:"))
        s.first_privacy_field_combo_box.setItemText(0, _translate("MainWindow", "Name"))
        s.first_privacy_field_combo_box.setItemText(1, _translate("MainWindow", "Country"))
        s.first_privacy_field_combo_box.setItemText(2, _translate("MainWindow", "Value"))
        s.label_2.setText(_translate("MainWindow", "Company Records "))
        s.second_filter_label.setText(_translate("MainWindow", "Please enter the second field to apply privacy filtering on:"))
        s.second_privacy_field_combo_box.setItemText(0, _translate("MainWindow", "Name"))
        s.second_privacy_field_combo_box.setItemText(1, _translate("MainWindow", "Country"))
        s.second_privacy_field_combo_box.setItemText(2, _translate("MainWindow", "Value"))
        s.DP_button.setText(_translate("MainWindow", "Apply Differential Privacy Filtering"))
        s.first_data_set_label.setText(_translate("MainWindow", "Change applied to first data set: 0.00%"))
        s.second_data_set_label.setText(_translate("MainWindow", "Change applied to second data set: 0.00%"))
        s.third_data_set_label.setText(_translate("MainWindow", "Total change applied to data set: 0.00%"))
        s.main_menu_text.setText(_translate("MainWindow", "To view the altered company records dataset, go back to the main menu"))

    def press(s):
        first_company_filter = str(s.first_privacy_field_combo_box.currentText())
        second = str(s.second_privacy_field_combo_box.currentText())

        read_company_records()
        test = np.arange(1, 1001)
        try:
            if first_company_filter == "Name":
                field_to_be_updated_one = 1
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        filterNames1(getHashMap().g(str(test[index]))[1], test[index],
                                     field_to_be_updated_one)
                s.first_data_set_label.setText("Change applied to first data set: " + "{:.2%}".format(
                    int(update1()) / len(test)))
            if first_company_filter == "Country":
                field_to_be_updated_one = 2
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        filter1COuntries(getHashMap().g(str(test[index]))[1], test[index],
                                         field_to_be_updated_one)
                s.first_data_set_label.setText("Change applied to first data set: " + "{:.2%}".format(
                    int(update1()) / len(test)))
            if first_company_filter == "Value":
                field_to_be_updated_one = 3
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        values1(getHashMap().g(str(test[index]))[1], test[index],
                                field_to_be_updated_one)
                s.first_data_set_label.setText("Change applied to first data set: " + "{:.2%}".format(
                    int(update1()) / len(test)))
            if second == "Name":
                tobeupdated = 1
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        names2(getHashMap().g(str(test[index]))[3], test[index],
                               tobeupdated)
                s.second_data_set_label.setText("Change applied to second data set: " + "{:.2%}".format(
                    int(update2()) / len(test)))
            if second == "Country":
                tobeupdated = 2
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        countries2(getHashMap().g(str(test[index]))[3], test[index],
                                   tobeupdated)
                s.second_data_set_label.setText("Change applied to second data set: " + "{:.2%}".format(
                    int(update2()) / len(test)))
            if second == "Value":
                tobeupdated = 3
                for index in range(len(test)):
                    if index == 0:
                        pass
                    else:
                        values2(getHashMap().g(str(test[index]))[3], test[index],
                                tobeupdated)
                s.second_data_set_label.setText("Change applied to second data set: " + "{:.2%}".format(
                    int(update2()) / len(test)))

            s.third_data_set_label.setText("Total change applied to data set: " + "{: .2%}".format(int(noiseCounter1 + noiseCounter2) / 6000))

            altered = "Write_Company_Data.csv"
            a = open(altered, "w+")
            a.close()
            write_company_records()

        except IndexError:
            message = QMessageBox()
            message.setIcon(QMessageBox.Critical)
            message.setText("Error with data update.")
            message.setInformativeText('You can only apply the noise to this data set once, please restart the application!')
            message.setWindowTitle("Error")
            message.exec_()
            pass


if __name__ == "__main__":
    import sys
    application = QtWidgets.QApplication(sys.argv)
    application.setApplicationName('Differential Privacy Engine')
    main = QtWidgets.QMainWindow()
    ui = mainWindow()
    ui.setupUi(main)
    main.show()
    sys.exit(application.exec_())
