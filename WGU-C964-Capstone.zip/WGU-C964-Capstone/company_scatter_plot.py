from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMessageBox
from pyqtgraph import PlotWidget
import pyqtgraph as pg
import csv
import string
from collections import Counter

companyName = []
alteredCompanyName = []


def readrecords():
    with open('Read_Company_Data.csv') as csvfile:
        unaltered = []
        read_csv = csv.reader(csvfile, delimiter=',')
        for row in read_csv:
            unaltered.append(row[1][1])
    company_name_records = Counter(unaltered)
    alpha = list(string.ascii_lowercase)
    out = []
    for a in alpha:
        out.append(a)
    for i in out:
        companyName.append((company_name_records[i]))


def readaltered():
    with open('Write_Company_Data.csv') as csvfile:
        altered = []
        read_csv = csv.reader(csvfile, delimiter=',')
        for row in read_csv:
            altered.append(row[1][1])
    company_name_records = Counter(altered)
    alpha = list(string.ascii_lowercase)
    out = []
    for a in alpha:
        out.append(a)
    for i in out:
        alteredCompanyName.append((company_name_records[i]))


class Ui_MainWindow_Company_Scatter_Plot(object):
    def setupUi(s, main):
        main.setObjectName("MainWindow")
        main.resize(800, 650)
        s.centralwidget = QtWidgets.QWidget(main)
        s.centralwidget.setObjectName("centralwidget")

        s.label = QtWidgets.QLabel(s.centralwidget)
        s.label.setGeometry(QtCore.QRect(10, 600, 850, 31))
        f = QtGui.QFont()
        f.setPointSize(10)
        s.label.setFont(f)
        s.label.setObjectName("label")

        readrecords()
        readaltered()
        alphabet_value = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26]
        unaltered_employee_names = companyName
        altered_employee_names = alteredCompanyName

        s.graphWidget = PlotWidget(s.centralwidget)
        s.graphWidget.setGeometry(QtCore.QRect(0, 0, 785, 580))
        s.graphWidget.setObjectName("graphWidget")
        main.setCentralWidget(s.centralwidget)
        s.statusbar = QtWidgets.QStatusBar(main)
        s.statusbar.setObjectName("statusbar")
        main.setStatusBar(s.statusbar)

        s.graphWidget.setLabel('left', 'Number of occurrences of company names first letter values', color='red', size=30)
        s.graphWidget.setLabel('bottom', 'Company Names sorted by first letter in a companies name', color='red', size=30)

        s.retranslateUi(main)
        QtCore.QMetaObject.connectSlotsByName(main)
        s.graphWidget.addLegend()
        s.graphWidget.showGrid(x=True, y=True)
        s.graphWidget.setXRange(0, 26.5, padding=0)
        s.graphWidget.setYRange(0, 300, padding=0)
        try:
            s.plot(alphabet_value, unaltered_employee_names, "Original Company Names", 'r')
            s.plot(alphabet_value, altered_employee_names, "Altered Company Names", 'b')
        except Exception:
            message = QMessageBox()
            message.setIcon(QMessageBox.Critical)
            message.setText("Error! Please close existing window.")
            message.setInformativeText('You can only have one window open at a time. Please close the existing window to continue!')
            message.setWindowTitle("Error")
            message.exec_()
            pass
    def plot(s, x, y, plotname, color):
        pen = pg.mkPen(color=color)
        s.graphWidget.plot(x, y, name=plotname, pen=pen, symbol='+', symbolSize=10, symbolBrush=(color))

    def retranslateUi(s, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Differential Privacy Engine"))
        s.label.setText(_translate("MainWindow",
                                      "NOTE: This graph displays the difference between company names if the Differential Privacy Engine includes the company name values."))


if __name__ == "__main__":
    import sys
    application = QtWidgets.QApplication(sys.argv)
    application.setApplicationName('Differential Privacy Engine')
    main = QtWidgets.QMainWindow()
    ui = Ui_MainWindow_Company_Scatter_Plot()
    ui.setupUi(main)
    main.show()
    sys.exit(application.exec_())
